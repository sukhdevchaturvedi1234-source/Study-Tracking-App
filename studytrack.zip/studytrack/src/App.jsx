import React, { useState, useEffect, useMemo } from 'react';
import {
  LayoutDashboard,
  BookOpen,
  ListTodo,
  CalendarClock,
  History,
  Bell,
  Settings,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Flame,
  ArrowUpDown,
  Trash2,
  Edit3,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  Download,
  Upload,
  Sun,
  Moon,
  Sparkles,
  BookmarkCheck,
  FileText,
  X,
  Layers,
  Check,
  RotateCcw,
  BellRing,
  Play,
  Calendar
} from 'lucide-react';

// --- STATUS CONFIGURATION (Exact Color-Coded Revision System with Solid Circle ●) ---
const STATUS_CONFIG = {
  not_started: {
    label: 'Not Started',
    dotColor: 'text-zinc-400 dark:text-zinc-500',
    badgeClass: 'bg-zinc-100 text-zinc-700 border-zinc-300 dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-700',
    borderLeftClass: 'border-l-zinc-400',
    daysText: 'Chapter never completed',
    priority: 4
  },
  recently_revised: {
    label: 'Recently Revised',
    dotColor: 'text-emerald-500',
    badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800',
    borderLeftClass: 'border-l-emerald-500',
    daysText: '0–2 days since revision',
    priority: 3
  },
  revision_due: {
    label: 'Revision Due',
    dotColor: 'text-amber-500',
    badgeClass: 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800',
    borderLeftClass: 'border-l-amber-500',
    daysText: '3–5 days since revision',
    priority: 2
  },
  overdue: {
    label: 'Overdue',
    dotColor: 'text-orange-500 animate-pulse',
    badgeClass: 'bg-orange-50 text-orange-800 border-orange-200 dark:bg-orange-950/50 dark:text-orange-300 dark:border-orange-800',
    borderLeftClass: 'border-l-orange-500',
    daysText: '6–9 days since revision',
    priority: 1
  },
  revise_asap: {
    label: 'Revise ASAP',
    dotColor: 'text-rose-600 animate-pulse',
    badgeClass: 'bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800',
    borderLeftClass: 'border-l-rose-600',
    daysText: '10+ days since revision',
    priority: 0
  }
};

const SUBJECT_COLORS = [
  { id: 'indigo', name: 'Indigo', bg: 'bg-indigo-600', bar: 'bg-indigo-600', light: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300' },
  { id: 'violet', name: 'Purple', bg: 'bg-purple-600', bar: 'bg-purple-600', light: 'bg-purple-50 text-purple-700 dark:bg-purple-950/50 dark:text-purple-300' },
  { id: 'cyan', name: 'Cyan', bg: 'bg-cyan-600', bar: 'bg-cyan-600', light: 'bg-cyan-50 text-cyan-700 dark:bg-cyan-950/50 dark:text-cyan-300' },
  { id: 'emerald', name: 'Emerald', bg: 'bg-emerald-600', bar: 'bg-emerald-600', light: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300' },
  { id: 'amber', name: 'Amber', bg: 'bg-amber-600', bar: 'bg-amber-600', light: 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300' },
  { id: 'rose', name: 'Rose', bg: 'bg-rose-600', bar: 'bg-rose-600', light: 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300' }
];

// --- DATE & TIME UTILITIES ---
function getElapsedCalendarDays(dateStr) {
  if (!dateStr) return null;
  const parsed = new Date(dateStr);
  if (isNaN(parsed.getTime())) return null;
  const now = new Date();
  const utcTarget = Date.UTC(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
  const utcNow = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
  const diff = Math.floor((utcNow - utcTarget) / (1000 * 60 * 60 * 24));
  return Math.max(0, diff);
}

function getNextDueDateString(lastRevisedStr) {
  if (!lastRevisedStr) return null;
  const d = new Date(lastRevisedStr);
  if (isNaN(d.getTime())) return null;
  // A chapter enters Yellow (Revision Due) 3 calendar days after last revision
  d.setDate(d.getDate() + 3);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

function formatDateDisplay(dateStr, includeTime = false) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  const opts = { month: 'short', day: 'numeric', year: 'numeric' };
  if (includeTime) {
    opts.hour = '2-digit';
    opts.minute = '2-digit';
  }
  return d.toLocaleDateString(undefined, opts);
}

function toInputDateValue(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '';
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getTodayDateString() {
  return toInputDateValue(new Date().toISOString());
}

function playRevisionChime() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.14); // E5
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch {
    // Ignore audio errors if blocked by browser autoplay policy
  }
}

// Fresh First-Launch State: 0 subjects and 0 chapters by default
const INITIAL_SUBJECTS = [];
const INITIAL_CHAPTERS = [];

export default function App() {
  // --- PERSISTENT STATE ---
  const [subjects, setSubjects] = useState(() => {
    try {
      const saved = localStorage.getItem('studytrack_v2_subjects');
      return saved ? JSON.parse(saved) : INITIAL_SUBJECTS;
    } catch {
      return INITIAL_SUBJECTS;
    }
  });

  const [chapters, setChapters] = useState(() => {
    try {
      const saved = localStorage.getItem('studytrack_v2_chapters');
      return saved ? JSON.parse(saved) : INITIAL_CHAPTERS;
    } catch {
      return INITIAL_CHAPTERS;
    }
  });

  const [isDarkMode, setIsDarkMode] = useState(() => {
    try {
      const saved = localStorage.getItem('studytrack_v2_theme');
      return saved ? saved === 'dark' : false;
    } catch {
      return false;
    }
  });

  const [notificationSettings, setNotificationSettings] = useState(() => {
    try {
      const saved = localStorage.getItem('studytrack_v2_notif');
      return saved
        ? JSON.parse(saved)
        : {
            enabled: true,
            preferredTime: '08:00',
            soundEnabled: true
          };
    } catch {
      return {
        enabled: true,
        preferredTime: '08:00',
        soundEnabled: true
      };
    }
  });

  // Navigation & UI state
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedSubjectId, setSelectedSubjectId] = useState(null);
  const [toast, setToast] = useState(null);

  // Modals state (No browser alert/confirm used anywhere)
  const [modalType, setModalType] = useState(null); // 'add_subject' | 'edit_subject' | 'add_chapter' | 'edit_chapter' | 'notes' | 'revise' | 'confirm'
  const [modalPayload, setModalPayload] = useState(null);

  // Search & Filter state (All Chapters view)
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSubject, setFilterSubject] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [sortField, setSortField] = useState('custom'); // 'custom' | 'urgency' | 'startedOn' | 'lastRevised' | 'title'
  const [sortDirection, setSortDirection] = useState('asc');

  const [browserNotifPermission, setBrowserNotifPermission] = useState(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'unsupported';
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('studytrack_v2_subjects', JSON.stringify(subjects));
    } catch (e) {
      console.error('Failed saving subjects', e);
    }
  }, [subjects]);

  useEffect(() => {
    try {
      localStorage.setItem('studytrack_v2_chapters', JSON.stringify(chapters));
    } catch (e) {
      console.error('Failed saving chapters', e);
    }
  }, [chapters]);

  useEffect(() => {
    try {
      localStorage.setItem('studytrack_v2_theme', isDarkMode ? 'dark' : 'light');
    } catch {}
  }, [isDarkMode]);

  useEffect(() => {
    try {
      localStorage.setItem('studytrack_v2_notif', JSON.stringify(notificationSettings));
    } catch {}
  }, [notificationSettings]);

  // Keep selectedSubjectId valid
  useEffect(() => {
    if (subjects.length > 0 && (!selectedSubjectId || !subjects.some(s => s.id === selectedSubjectId))) {
      setSelectedSubjectId(subjects[0].id);
    } else if (subjects.length === 0 && selectedSubjectId !== null) {
      setSelectedSubjectId(null);
    }
  }, [subjects, selectedSubjectId]);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => {
      setToast((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  // --- AUTOMATIC COLOUR-CODED REVISION STATUS ENGINE ---
  // Rules:
  // - Never completed (lastRevised is null) => Grey (not_started)
  // - 0–2 calendar days => Green (recently_revised)
  // - 3–5 calendar days => Yellow (revision_due)
  // - 6–9 calendar days => Orange (overdue)
  // - 10+ calendar days => Red (revise_asap)
  const computeStatus = (chapter) => {
    if (!chapter.lastRevised) {
      return 'not_started';
    }
    // Check active snooze
    if (chapter.snoozedUntil) {
      const snoozeEnd = new Date(chapter.snoozedUntil);
      if (snoozeEnd > new Date()) {
        return 'recently_revised';
      }
    }
    const elapsedDays = getElapsedCalendarDays(chapter.lastRevised);
    if (elapsedDays === null) return 'not_started';
    if (elapsedDays <= 2) return 'recently_revised';
    if (elapsedDays <= 5) return 'revision_due';
    if (elapsedDays <= 9) return 'overdue';
    return 'revise_asap';
  };

  const enrichedChapters = useMemo(() => {
    return chapters.map((ch) => {
      const status = computeStatus(ch);
      const daysSinceRev = ch.lastRevised ? getElapsedCalendarDays(ch.lastRevised) : null;
      const nextDueDate = ch.lastRevised ? getNextDueDateString(ch.lastRevised) : null;
      return {
        ...ch,
        status,
        daysSinceRev,
        nextDueDate
      };
    });
  }, [chapters]);

  // Dashboard Metrics
  const metrics = useMemo(() => {
    const totalSubjects = subjects.length;
    const totalChapters = enrichedChapters.length;
    const notStarted = enrichedChapters.filter(c => c.status === 'not_started').length;
    const completedChapters = totalChapters - notStarted;
    const recentlyRevised = enrichedChapters.filter(c => c.status === 'recently_revised').length;
    const dueCount = enrichedChapters.filter(c => c.status === 'revision_due').length;
    const overdueCount = enrichedChapters.filter(c => c.status === 'overdue').length;
    const asapCount = enrichedChapters.filter(c => c.status === 'revise_asap').length;
    const completionPct = totalChapters === 0 ? 0 : Math.round((completedChapters / totalChapters) * 100);

    return {
      totalSubjects,
      totalChapters,
      completedChapters,
      notStarted,
      recentlyRevised,
      dueCount,
      overdueCount,
      asapCount,
      completionPct
    };
  }, [subjects, enrichedChapters]);

  // Priority Attention List: Red (0) -> Orange (1) -> Yellow (2)
  const attentionChapters = useMemo(() => {
    return enrichedChapters
      .filter(c => ['revise_asap', 'overdue', 'revision_due'].includes(c.status))
      .sort((a, b) => {
        const pA = STATUS_CONFIG[a.status].priority;
        const pB = STATUS_CONFIG[b.status].priority;
        if (pA !== pB) return pA - pB;
        return (b.daysSinceRev || 0) - (a.daysSinceRev || 0);
      });
  }, [enrichedChapters]);

  // --- CRUD & REVISION HANDLERS ---

  const handleStartChapter = (chapterId) => {
    const today = getTodayDateString();
    setChapters(prev =>
      prev.map(ch => (ch.id === chapterId ? { ...ch, startedOn: ch.startedOn || today } : ch))
    );
    showToast('Chapter started date recorded! Complete it to begin the revision timer.');
  };

  const handleMarkRevised = (chapterId, sessionNote = '', customDateISO = null) => {
    const timestamp = customDateISO ? new Date(customDateISO).toISOString() : new Date().toISOString();
    const datePart = toInputDateValue(timestamp);

    setChapters(prev =>
      prev.map(ch => {
        if (ch.id !== chapterId) return ch;
        const prevCount = ch.revisionHistory ? ch.revisionHistory.length : 0;
        const newEntry = {
          id: `rev-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp,
          count: prevCount + 1,
          note: sessionNote.trim() || (prevCount === 0 ? 'Initial chapter completion' : 'Scheduled revision completed')
        };
        return {
          ...ch,
          startedOn: ch.startedOn || datePart,
          lastRevised: timestamp,
          snoozedUntil: null,
          revisionHistory: [newEntry, ...(ch.revisionHistory || [])]
        };
      })
    );

    if (notificationSettings.soundEnabled) {
      playRevisionChime();
    }
    showToast('Chapter marked as revised! Status is now Green (Recently Revised).');
  };

  const handleSnoozeChapter = (chapterId, days = 1) => {
    const target = new Date();
    target.setDate(target.getDate() + days);
    setChapters(prev =>
      prev.map(ch => (ch.id === chapterId ? { ...ch, snoozedUntil: target.toISOString() } : ch))
    );
    showToast(`Reminder snoozed for ${days} day${days > 1 ? 's' : ''}.`);
  };

  const handleReorderChapter = (chapterId, direction) => {
    const current = chapters.find(c => c.id === chapterId);
    if (!current) return;
    const subChapters = chapters
      .filter(c => c.subjectId === current.subjectId)
      .sort((a, b) => (a.order || 0) - (b.order || 0));

    const idx = subChapters.findIndex(c => c.id === chapterId);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= subChapters.length) return;

    const neighbor = subChapters[swapIdx];
    setChapters(prev =>
      prev.map(c => {
        if (c.id === current.id) return { ...c, order: swapIdx };
        if (c.id === neighbor.id) return { ...c, order: idx };
        return c;
      })
    );
  };

  const handleUpdateChapterDates = (chapterId, field, dateValue) => {
    setChapters(prev =>
      prev.map(ch => {
        if (ch.id !== chapterId) return ch;
        if (field === 'startedOn') {
          return { ...ch, startedOn: dateValue || null };
        }
        if (field === 'lastRevised') {
          if (!dateValue) {
            return { ...ch, lastRevised: null };
          }
          // Preserve local midnight ISO timestamp so elapsed days calculate accurately
          const parts = dateValue.split('-');
          const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]), 12, 0, 0);
          return {
            ...ch,
            startedOn: ch.startedOn || dateValue,
            lastRevised: d.toISOString()
          };
        }
        return ch;
      })
    );
    showToast('Date updated.');
  };

  // Browser Notification Trigger
  const requestNotificationPermission = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setBrowserNotifPermission('unsupported');
      showToast('Browser notifications are not supported on this device.');
      return;
    }
    try {
      const perm = await Notification.requestPermission();
      setBrowserNotifPermission(perm);
      if (perm === 'granted') {
        showToast('Notifications enabled!');
        sendTestBrowserNotification();
      } else {
        showToast('Notification permission was not granted.');
      }
    } catch {
      showToast('Could not request notification permission.');
    }
  };

  const sendTestBrowserNotification = () => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      const sampleChapter = attentionChapters[0]?.title || 'Real Numbers';
      try {
        new Notification('StudyTrack — Revision Reminder', {
          body: `Your chapter ${sampleChapter} is due for revision today.\nTime to revise!`
        });
        showToast('Test reminder notification sent!');
      } catch {
        showToast('In-app reminder active (system notification blocked by environment).');
      }
    } else {
      showToast('Please enable browser notification permissions first.');
    }
  };

  // Export & Import JSON
  const handleExportJSON = () => {
    const payload = {
      app: 'StudyTrack',
      version: '2.0',
      exportedAt: new Date().toISOString(),
      subjects,
      chapters,
      notificationSettings
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `StudyTrack_Backup_${getTodayDateString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Syllabus backup exported!');
  };

  const handleImportJSON = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (!Array.isArray(parsed.subjects) || !Array.isArray(parsed.chapters)) {
          showToast('Invalid StudyTrack backup file.');
          return;
        }
        setSubjects(parsed.subjects);
        setChapters(parsed.chapters);
        if (parsed.notificationSettings) {
          setNotificationSettings(parsed.notificationSettings);
        }
        showToast('Backup restored successfully!');
      } catch {
        showToast('Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'subjects', label: 'My Subjects', icon: BookOpen },
    { id: 'all_chapters', label: 'All Chapters', icon: ListTodo },
    { id: 'schedule', label: 'Revision Schedule', icon: CalendarClock },
    { id: 'history', label: 'Revision History', icon: History },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: attentionChapters.length },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className={isDarkMode ? 'dark' : ''}>
      <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 dark:bg-zinc-950 text-slate-800 dark:text-zinc-100 font-sans">
        
        {/* Toast Banner */}
        {toast && (
          <div className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-zinc-900 shadow-xl border border-slate-700/40 text-xs sm:text-sm font-semibold">
            <BookmarkCheck className="w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" />
            <span>{toast}</span>
          </div>
        )}

        {/* --- DESKTOP SIDEBAR --- */}
        <aside className="hidden md:flex flex-col w-64 border-r border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shrink-0">
          <div className="p-5 flex items-center justify-between border-b border-slate-200 dark:border-zinc-800">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-sm">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h1 className="font-bold text-base tracking-tight text-slate-900 dark:text-white leading-none">
                  StudyTrack
                </h1>
                <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-1 font-medium">
                  Syllabus & Revision Manager
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-zinc-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-zinc-800 transition"
              title="Toggle Light/Dark Mode"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>

          <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
                    active
                      ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 font-semibold'
                      : 'text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${active ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge > 0 && (
                    <span className="px-2 py-0.5 text-[11px] font-bold rounded-full bg-rose-500 text-white">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Status Legend & Overall Progress Box */}
          <div className="p-4 m-3 rounded-xl bg-slate-50 dark:bg-zinc-950/60 border border-slate-200 dark:border-zinc-800 space-y-3 text-xs">
            <div>
              <div className="flex justify-between items-center font-semibold text-slate-700 dark:text-zinc-300 mb-1.5">
                <span>Overall Syllabus</span>
                <span className="text-indigo-600 dark:text-indigo-400 font-bold">{metrics.completionPct}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-zinc-800 overflow-hidden">
                <div
                  className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                  style={{ width: `${metrics.completionPct}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 dark:text-zinc-500 mt-1">
                {metrics.completedChapters} of {metrics.totalChapters} chapters completed
              </p>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-zinc-800 space-y-1 text-[11px] text-slate-500 dark:text-zinc-400">
              <div className="font-semibold text-slate-700 dark:text-zinc-300 mb-1">Revision Status Key:</div>
              <div className="flex items-center justify-between">
                <span><span className="text-emerald-500 mr-1.5">●</span>Recently Revised</span>
                <span>0–2d</span>
              </div>
              <div className="flex items-center justify-between">
                <span><span className="text-amber-500 mr-1.5">●</span>Revision Due</span>
                <span>3–5d</span>
              </div>
              <div className="flex items-center justify-between">
                <span><span className="text-orange-500 mr-1.5">●</span>Overdue</span>
                <span>6–9d</span>
              </div>
              <div className="flex items-center justify-between">
                <span><span className="text-rose-600 mr-1.5">●</span>Revise ASAP</span>
                <span>10+d</span>
              </div>
              <div className="flex items-center justify-between">
                <span><span className="text-zinc-400 mr-1.5">●</span>Not Started</span>
                <span>—</span>
              </div>
            </div>
          </div>
        </aside>

        {/* --- MOBILE HEADER --- */}
        <header className="md:hidden sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-white dark:bg-zinc-900 border-b border-slate-200 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-bold text-base text-slate-900 dark:text-white">StudyTrack</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('notifications')}
              className="p-2 relative rounded-lg text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
              {attentionChapters.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500" />
              )}
            </button>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-lg text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800"
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </header>

        {/* --- MAIN VIEWPORT --- */}
        <main className="flex-1 overflow-y-auto pb-24 md:pb-10">
          <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
            {activeTab === 'dashboard' && (
              <DashboardView
                metrics={metrics}
                subjects={subjects}
                enrichedChapters={enrichedChapters}
                attentionChapters={attentionChapters}
                onAddSubject={() => {
                  setModalPayload(null);
                  setModalType('add_subject');
                }}
                onAddChapter={() => {
                  if (subjects.length === 0) {
                    setModalPayload(null);
                    setModalType('add_subject');
                  } else {
                    setModalPayload({ subjectId: selectedSubjectId || subjects[0].id });
                    setModalType('add_chapter');
                  }
                }}
                onOpenRevise={(ch) => {
                  setModalPayload(ch);
                  setModalType('revise');
                }}
                onOpenNotes={(ch) => {
                  setModalPayload(ch);
                  setModalType('notes');
                }}
                onSelectSubject={(subId) => {
                  setSelectedSubjectId(subId);
                  setActiveTab('subjects');
                }}
                onNavigate={setActiveTab}
              />
            )}

            {activeTab === 'subjects' && (
              <SubjectsView
                subjects={subjects}
                selectedSubjectId={selectedSubjectId}
                setSelectedSubjectId={setSelectedSubjectId}
                enrichedChapters={enrichedChapters}
                onAddSubject={() => {
                  setModalPayload(null);
                  setModalType('add_subject');
                }}
                onEditSubject={(sub) => {
                  setModalPayload(sub);
                  setModalType('edit_subject');
                }}
                onDeleteSubject={(sub) => {
                  setModalPayload({
                    title: `Delete Subject "${sub.name}"?`,
                    message: `This will permanently delete "${sub.name}" and all chapters under it.`,
                    confirmLabel: 'Delete Subject',
                    onConfirm: () => {
                      setSubjects(prev => prev.filter(s => s.id !== sub.id));
                      setChapters(prev => prev.filter(c => c.subjectId !== sub.id));
                      showToast(`Subject "${sub.name}" deleted.`);
                    }
                  });
                  setModalType('confirm');
                }}
                onAddChapter={(subId) => {
                  setModalPayload({ subjectId: subId });
                  setModalType('add_chapter');
                }}
                onEditChapter={(ch) => {
                  setModalPayload(ch);
                  setModalType('edit_chapter');
                }}
                onDeleteChapter={(ch) => {
                  setModalPayload({
                    title: `Delete Chapter "${ch.title}"?`,
                    message: 'Are you sure you want to remove this chapter and its revision history?',
                    confirmLabel: 'Delete Chapter',
                    onConfirm: () => {
                      setChapters(prev => prev.filter(c => c.id !== ch.id));
                      showToast('Chapter deleted.');
                    }
                  });
                  setModalType('confirm');
                }}
                onStartChapter={handleStartChapter}
                onOpenRevise={(ch) => {
                  setModalPayload(ch);
                  setModalType('revise');
                }}
                onOpenNotes={(ch) => {
                  setModalPayload(ch);
                  setModalType('notes');
                }}
                onReorderChapter={handleReorderChapter}
                onUpdateChapterDates={handleUpdateChapterDates}
              />
            )}

            {activeTab === 'all_chapters' && (
              <AllChaptersView
                subjects={subjects}
                enrichedChapters={enrichedChapters}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                filterSubject={filterSubject}
                setFilterSubject={setFilterSubject}
                filterStatus={filterStatus}
                setFilterStatus={setFilterStatus}
                sortField={sortField}
                setSortField={setSortField}
                sortDirection={sortDirection}
                setSortDirection={setSortDirection}
                onAddChapter={() => {
                  if (subjects.length === 0) {
                    setModalPayload(null);
                    setModalType('add_subject');
                  } else {
                    setModalPayload({ subjectId: subjects[0].id });
                    setModalType('add_chapter');
                  }
                }}
                onStartChapter={handleStartChapter}
                onOpenRevise={(ch) => {
                  setModalPayload(ch);
                  setModalType('revise');
                }}
                onOpenNotes={(ch) => {
                  setModalPayload(ch);
                  setModalType('notes');
                }}
                onEditChapter={(ch) => {
                  setModalPayload(ch);
                  setModalType('edit_chapter');
                }}
                onDeleteChapter={(ch) => {
                  setModalPayload({
                    title: `Delete Chapter "${ch.title}"?`,
                    message: 'This action cannot be undone.',
                    confirmLabel: 'Delete Chapter',
                    onConfirm: () => {
                      setChapters(prev => prev.filter(c => c.id !== ch.id));
                      showToast('Chapter deleted.');
                    }
                  });
                  setModalType('confirm');
                }}
                onUpdateChapterDates={handleUpdateChapterDates}
              />
            )}

            {activeTab === 'schedule' && (
              <RevisionScheduleView
                subjects={subjects}
                enrichedChapters={enrichedChapters}
                onOpenRevise={(ch) => {
                  setModalPayload(ch);
                  setModalType('revise');
                }}
                onSnooze={handleSnoozeChapter}
                onOpenNotes={(ch) => {
                  setModalPayload(ch);
                  setModalType('notes');
                }}
              />
            )}

            {activeTab === 'history' && (
              <RevisionHistoryView
                subjects={subjects}
                enrichedChapters={enrichedChapters}
              />
            )}

            {activeTab === 'notifications' && (
              <NotificationsView
                subjects={subjects}
                attentionChapters={attentionChapters}
                browserNotifPermission={browserNotifPermission}
                onRequestPermission={requestNotificationPermission}
                onSendTestNotification={sendTestBrowserNotification}
                notificationSettings={notificationSettings}
                setNotificationSettings={setNotificationSettings}
                onOpenRevise={(ch) => {
                  setModalPayload(ch);
                  setModalType('revise');
                }}
                onSnooze={handleSnoozeChapter}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                subjects={subjects}
                chapters={chapters}
                isDarkMode={isDarkMode}
                setIsDarkMode={setIsDarkMode}
                notificationSettings={notificationSettings}
                setNotificationSettings={setNotificationSettings}
                onExport={handleExportJSON}
                onImport={handleImportJSON}
                onClearAll={() => {
                  setModalPayload({
                    title: 'Clear All StudyTrack Data?',
                    message: 'This will remove all subjects, chapters, notes, and revision history from this browser.',
                    confirmLabel: 'Clear Everything',
                    onConfirm: () => {
                      setSubjects([]);
                      setChapters([]);
                      setSelectedSubjectId(null);
                      localStorage.removeItem('studytrack_v2_subjects');
                      localStorage.removeItem('studytrack_v2_chapters');
                      showToast('All data cleared.');
                    }
                  });
                  setModalType('confirm');
                }}
              />
            )}
          </div>
        </main>

        {/* --- MOBILE BOTTOM NAVIGATION BAR --- */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white dark:bg-zinc-900 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-around px-1 py-1.5">
          {[
            { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
            { id: 'subjects', label: 'Subjects', icon: BookOpen },
            { id: 'all_chapters', label: 'Chapters', icon: ListTodo },
            { id: 'schedule', label: 'Schedule', icon: CalendarClock },
            { id: 'history', label: 'History', icon: History },
            { id: 'settings', label: 'Settings', icon: Settings }
          ].map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg text-[10px] font-medium ${
                  active
                    ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                    : 'text-slate-500 dark:text-zinc-400'
                }`}
              >
                <Icon className="w-5 h-5 mb-0.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* --- MODALS --- */}
        {(modalType === 'add_subject' || modalType === 'edit_subject') && (
          <SubjectModal
            mode={modalType}
            initialData={modalPayload}
            onClose={() => setModalType(null)}
            onSave={(data) => {
              if (modalType === 'add_subject') {
                const newSub = {
                  id: `sub-${Date.now()}`,
                  name: data.name,
                  code: data.code,
                  color: data.color
                };
                setSubjects(prev => [...prev, newSub]);
                setSelectedSubjectId(newSub.id);
                showToast(`Subject "${newSub.name}" created!`);
              } else {
                setSubjects(prev =>
                  prev.map(s => (s.id === modalPayload.id ? { ...s, ...data } : s))
                );
                showToast('Subject updated.');
              }
              setModalType(null);
            }}
          />
        )}

        {(modalType === 'add_chapter' || modalType === 'edit_chapter') && (
          <ChapterModal
            mode={modalType}
            subjects={subjects}
            initialData={modalPayload}
            onClose={() => setModalType(null)}
            onSave={(data) => {
              if (modalType === 'add_chapter') {
                const existingCount = chapters.filter(c => c.subjectId === data.subjectId).length;
                const titles = data.titles && data.titles.length > 0 ? data.titles : [data.title];
                const nowISO = new Date().toISOString();

                const created = titles.map((t, i) => ({
                  id: `ch-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`,
                  subjectId: data.subjectId,
                  title: t,
                  order: existingCount + i,
                  startedOn: data.startedOn || null,
                  lastRevised: data.markCompletedNow ? nowISO : null,
                  snoozedUntil: null,
                  importantNotes: {
                    struggles: '',
                    focus: '',
                    mistakes: '',
                    formulas: '',
                    reminders: ''
                  },
                  revisionHistory: data.markCompletedNow
                    ? [
                        {
                          id: `rev-${Date.now()}-${i}`,
                          timestamp: nowISO,
                          count: 1,
                          note: 'Initial chapter completion'
                        }
                      ]
                    : []
                }));

                setChapters(prev => [...prev, ...created]);
                showToast(
                  created.length > 1
                    ? `${created.length} chapters added!`
                    : `Chapter "${created[0].title}" added!`
                );
              } else {
                setChapters(prev =>
                  prev.map(c =>
                    c.id === modalPayload.id
                      ? {
                          ...c,
                          title: data.title,
                          subjectId: data.subjectId,
                          startedOn: data.startedOn || null
                        }
                      : c
                  )
                );
                showToast('Chapter updated.');
              }
              setModalType(null);
            }}
          />
        )}

        {modalType === 'revise' && modalPayload && (
          <ReviseModal
            chapter={enrichedChapters.find(c => c.id === modalPayload.id) || modalPayload}
            onClose={() => setModalType(null)}
            onConfirm={(chapterId, note, customDate) => {
              handleMarkRevised(chapterId, note, customDate);
              setModalType(null);
            }}
          />
        )}

        {modalType === 'notes' && modalPayload && (
          <NotesModal
            chapter={enrichedChapters.find(c => c.id === modalPayload.id) || modalPayload}
            subject={subjects.find(s => s.id === modalPayload.subjectId)}
            onClose={() => setModalType(null)}
            onSaveNotes={(chapterId, updatedNotes) => {
              // Important requirement: Editing chapter notes must NEVER reset revision history or dates
              setChapters(prev =>
                prev.map(c => (c.id === chapterId ? { ...c, importantNotes: updatedNotes } : c))
              );
              showToast('Important notes saved (revision history preserved).');
              setModalType(null);
            }}
            onQuickRevise={(ch) => {
              setModalPayload(ch);
              setModalType('revise');
            }}
          />
        )}

        {modalType === 'confirm' && modalPayload && (
          <ConfirmModal
            title={modalPayload.title}
            message={modalPayload.message}
            confirmLabel={modalPayload.confirmLabel}
            onClose={() => setModalType(null)}
            onConfirm={() => {
              modalPayload.onConfirm();
              setModalType(null);
            }}
          />
        )}
      </div>
    </div>
  );
}

// ============================================================================
// STATUS BADGE COMPONENT (Always displays Solid Circle ● + Colour-Coded Label)
// ============================================================================
function StatusBadge({ status }) {
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.not_started;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border whitespace-nowrap ${cfg.badgeClass}`}
    >
      <span className={`text-xs leading-none ${cfg.dotColor}`}>●</span>
      <span>{cfg.label}</span>
    </span>
  );
}

// ============================================================================
// VIEW 1: DASHBOARD
// ============================================================================
function DashboardView({
  metrics,
  subjects,
  enrichedChapters,
  attentionChapters,
  onAddSubject,
  onAddChapter,
  onOpenRevise,
  onOpenNotes,
  onSelectSubject,
  onNavigate
}) {
  // Upcoming deadlines: Chapters currently in Green (Recently Revised) showing when they enter Yellow
  const upcomingDeadlines = enrichedChapters
    .filter(c => c.status === 'recently_revised')
    .sort((a, b) => (b.daysSinceRev || 0) - (a.daysSinceRev || 0));

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-700 p-6 sm:p-8 text-white shadow-lg">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Automatic Spaced Revision Manager</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            {metrics.totalSubjects === 0
              ? 'Start Building Your Syllabus'
              : 'Stay Ahead of Your Revisions'}
          </h2>
          <p className="text-indigo-100 text-sm sm:text-base">
            {metrics.totalSubjects === 0
              ? 'Your workspace is fresh and empty. Create your custom subjects and add chapters from your course or board to track completion and automatic revision intervals.'
              : metrics.asapCount > 0
              ? `Immediate attention needed: ${metrics.asapCount} chapter${metrics.asapCount > 1 ? 's are' : ' is'} 10+ days past revision (Red ● Revise ASAP).`
              : attentionChapters.length > 0
              ? `You have ${attentionChapters.length} chapter${attentionChapters.length > 1 ? 's' : ''} due or overdue for revision today.`
              : 'Every completed chapter is fresh in Green status! Keep up the momentum.'}
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={onAddSubject}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white text-indigo-900 font-bold text-xs sm:text-sm shadow hover:bg-indigo-50 transition"
            >
              <Plus className="w-4 h-4" />
              {metrics.totalSubjects === 0 ? 'Add First Subject' : 'New Subject'}
            </button>
            {metrics.totalSubjects > 0 && (
              <button
                onClick={onAddChapter}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-semibold text-xs sm:text-sm transition"
              >
                <Plus className="w-4 h-4" />
                Add Chapter
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Stat Cards Grid (All 7 Required Dashboard Metrics) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        <StatCard
          label="Total Subjects"
          value={metrics.totalSubjects}
          sub="Custom courses"
          dotClass="text-indigo-500"
        />
        <StatCard
          label="Total Chapters"
          value={metrics.totalChapters}
          sub={`${metrics.completionPct}% syllabus done`}
          dotClass="text-cyan-500"
        />
        <StatCard
          label="Completed"
          value={metrics.completedChapters}
          sub={`${metrics.recentlyRevised} Green ● fresh`}
          dotClass="text-emerald-500"
        />
        <StatCard
          label="Not Started"
          value={metrics.notStarted}
          sub="Grey ● pending"
          dotClass="text-zinc-400"
        />
        <StatCard
          label="Revision Due"
          value={metrics.dueCount}
          sub="Yellow ● (3–5d)"
          dotClass="text-amber-500"
        />
        <StatCard
          label="Overdue"
          value={metrics.overdueCount}
          sub="Orange ● (6–9d)"
          dotClass="text-orange-500"
        />
        <StatCard
          label="Revise ASAP"
          value={metrics.asapCount}
          sub="Red ● (10+ days)"
          dotClass="text-rose-600"
          urgent={metrics.asapCount > 0}
        />
      </div>

      {/* Overall Syllabus Completion Progress Bar */}
      <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
              Overall Syllabus Completion
            </h3>
            <p className="text-xs text-slate-500 dark:text-zinc-400">
              {metrics.completedChapters} completed out of {metrics.totalChapters} total chapters ({metrics.notStarted} Grey ● Not Started)
            </p>
          </div>
          <span className="text-xl font-extrabold text-indigo-600 dark:text-indigo-400">
            {metrics.completionPct}%
          </span>
        </div>
        <div className="w-full h-3 rounded-full bg-slate-100 dark:bg-zinc-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-600 to-emerald-500 rounded-full transition-all duration-500"
            style={{ width: `${metrics.completionPct}%` }}
          />
        </div>
      </div>

      {/* Empty Onboarding State if Freshly Opened */}
      {subjects.length === 0 ? (
        <div className="p-10 text-center rounded-2xl bg-white dark:bg-zinc-900 border-2 border-dashed border-slate-300 dark:border-zinc-800 space-y-4">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <BookOpen className="w-7 h-7" />
          </div>
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              No Subjects or Chapters Added Yet
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
              Add your subjects and chapters yourself from any board, university, or competitive exam syllabus. New chapters begin as <span className="font-semibold text-zinc-600 dark:text-zinc-300">● Not Started (Grey)</span> until you complete them.
            </p>
          </div>
          <button
            onClick={onAddSubject}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            Create Your First Subject
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Columns: Today's Revision Tasks & Overdue Priority List + Upcoming Deadlines */}
          <div className="lg:col-span-2 space-y-6">
            {/* Overdue & Due Priority Queue */}
            <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-rose-500" />
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    Today's Revision Tasks & Overdue Priority List
                  </h3>
                </div>
                <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
                  {attentionChapters.length} Due
                </span>
              </div>

              {attentionChapters.length === 0 ? (
                <div className="p-6 text-center rounded-xl bg-slate-50 dark:bg-zinc-800/40 text-xs text-slate-500 dark:text-zinc-400 space-y-1">
                  <div className="font-semibold text-slate-700 dark:text-zinc-200">
                    All caught up for today!
                  </div>
                  <p>No chapters are currently in Yellow, Orange, or Red status.</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {attentionChapters.map((ch) => {
                    const sub = subjects.find(s => s.id === ch.subjectId);
                    const cfg = STATUS_CONFIG[ch.status];
                    return (
                      <div
                        key={ch.id}
                        className={`p-3.5 rounded-xl bg-slate-50/70 dark:bg-zinc-800/40 border border-slate-200 dark:border-zinc-800 border-l-4 ${cfg.borderLeftClass} flex flex-col sm:flex-row sm:items-center justify-between gap-3`}
                      >
                        <div className="space-y-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            {sub && (
                              <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-300 border border-slate-200 dark:border-zinc-700">
                                {sub.code || sub.name}
                              </span>
                            )}
                            <StatusBadge status={ch.status} />
                            <span className="text-xs text-slate-500 dark:text-zinc-400">
                              {ch.daysSinceRev}d since last revision
                            </span>
                          </div>
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                            {ch.title}
                          </h4>
                        </div>
                        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                          <button
                            onClick={() => onOpenNotes(ch)}
                            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 text-slate-700 dark:text-zinc-300 hover:bg-slate-100"
                          >
                            Notes
                          </button>
                          <button
                            onClick={() => onOpenRevise(ch)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            Mark Revised
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Upcoming Revision Deadlines */}
            <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-500" />
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    Upcoming Revision Deadlines (Green → Yellow)
                  </h3>
                </div>
                <span className="text-xs text-slate-400">{upcomingDeadlines.length} active</span>
              </div>

              {upcomingDeadlines.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-zinc-400 py-2">
                  Complete or revise a chapter to see its next scheduled revision date here.
                </p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-zinc-800 text-xs">
                  {upcomingDeadlines.slice(0, 5).map((ch) => {
                    const sub = subjects.find(s => s.id === ch.subjectId);
                    return (
                      <div key={ch.id} className="py-2.5 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <span className="font-semibold text-slate-900 dark:text-white">{ch.title}</span>
                          <span className="text-slate-400 ml-2">({sub?.name})</span>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 font-semibold">
                            Due on {ch.nextDueDate}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Subject-wise Completion Progress */}
          <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-4 h-fit">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Subject-wise Progress
              </h3>
              <button
                onClick={onAddSubject}
                className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                + Add Subject
              </button>
            </div>

            <div className="space-y-3">
              {subjects.map((sub) => {
                const subChapters = enrichedChapters.filter(c => c.subjectId === sub.id);
                const total = subChapters.length;
                const done = subChapters.filter(c => c.status !== 'not_started').length;
                const pct = total === 0 ? 0 : Math.round((done / total) * 100);
                const greyCount = total - done;
                const urgentCount = subChapters.filter(c => ['overdue', 'revise_asap'].includes(c.status)).length;

                return (
                  <div
                    key={sub.id}
                    onClick={() => onSelectSubject(sub.id)}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 hover:border-indigo-400 dark:hover:border-indigo-600 cursor-pointer transition space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-900 dark:text-white truncate">
                        {sub.name}
                      </span>
                      <span className="text-xs font-extrabold text-indigo-600 dark:text-indigo-400">
                        {pct}%
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-zinc-800 overflow-hidden">
                      <div
                        className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-zinc-400">
                      <span>{done}/{total} completed ({greyCount} ● Grey)</span>
                      {urgentCount > 0 ? (
                        <span className="text-rose-600 dark:text-rose-400 font-bold">
                          {urgentCount} overdue
                        </span>
                      ) : (
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                          On track
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, sub, dotClass, urgent = false }) {
  return (
    <div
      className={`p-3.5 rounded-2xl bg-white dark:bg-zinc-900 border ${
        urgent ? 'border-rose-400 dark:border-rose-700' : 'border-slate-200 dark:border-zinc-800'
      } shadow-sm flex flex-col justify-between`}
    >
      <div className="flex items-center justify-between gap-1">
        <span className="text-[11px] font-semibold text-slate-500 dark:text-zinc-400">{label}</span>
        <span className={`text-sm leading-none ${dotClass}`}>●</span>
      </div>
      <div className="mt-2">
        <div className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white leading-none">
          {value}
        </div>
        <div className="text-[10px] text-slate-400 dark:text-zinc-500 font-medium mt-1 truncate">
          {sub}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// VIEW 2: MY SUBJECTS & MAIN CHAPTER TABLE
// ============================================================================
function SubjectsView({
  subjects,
  selectedSubjectId,
  setSelectedSubjectId,
  enrichedChapters,
  onAddSubject,
  onEditSubject,
  onDeleteSubject,
  onAddChapter,
  onEditChapter,
  onDeleteChapter,
  onStartChapter,
  onOpenRevise,
  onOpenNotes,
  onReorderChapter,
  onUpdateChapterDates
}) {
  if (subjects.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">My Subjects</h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
              Create custom subjects for any class, board, or course.
            </p>
          </div>
        </div>
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-zinc-900 border-2 border-dashed border-slate-300 dark:border-zinc-800 space-y-4">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-lg text-slate-900 dark:text-white">No Subjects Created Yet</h3>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400 max-w-md mx-auto">
            Add your first subject to unlock its dedicated Chapter Management Table.
          </p>
          <button
            onClick={onAddSubject}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Add First Subject
          </button>
        </div>
      </div>
    );
  }

  const currentSubject = subjects.find(s => s.id === selectedSubjectId) || subjects[0];
  const subjectChapters = enrichedChapters
    .filter(c => c.subjectId === currentSubject.id)
    .sort((a, b) => (a.order || 0) - (b.order || 0));

  const completedCount = subjectChapters.filter(c => c.status !== 'not_started').length;
  const pct = subjectChapters.length === 0 ? 0 : Math.round((completedCount / subjectChapters.length) * 100);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Subject & Chapter Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
            Track each subject independently, record start & revision dates, and manage chapter notes.
          </p>
        </div>
        <button
          onClick={onAddSubject}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-zinc-900 text-xs sm:text-sm font-bold self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Subject
        </button>
      </div>

      {/* Subject Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-zinc-800">
        {subjects.map((sub) => {
          const active = sub.id === currentSubject.id;
          const count = enrichedChapters.filter(c => c.subjectId === sub.id).length;
          return (
            <button
              key={sub.id}
              onClick={() => setSelectedSubjectId(sub.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition ${
                active
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-white dark:bg-zinc-900 text-slate-700 dark:text-zinc-300 border border-slate-200 dark:border-zinc-800 hover:bg-slate-100'
              }`}
            >
              <span>{sub.name}</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                  active ? 'bg-indigo-800 text-white' : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Active Subject Header Card */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              {currentSubject.code || 'COURSE'}
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs text-slate-500 dark:text-zinc-400">
              {completedCount} of {subjectChapters.length} chapters completed ({pct}%)
            </span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
            {currentSubject.name}
          </h3>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onAddChapter(currentSubject.id)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Add Chapter
          </button>
          <button
            onClick={() => onEditSubject(currentSubject)}
            className="p-2 rounded-xl border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800"
            title="Rename Subject"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDeleteSubject(currentSubject)}
            className="p-2 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
            title="Delete Subject"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Chapter Table */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-slate-200 dark:border-zinc-800 shadow-sm overflow-hidden">
        {subjectChapters.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <FileText className="w-9 h-9 mx-auto text-slate-300 dark:text-zinc-600" />
            <h4 className="font-bold text-slate-800 dark:text-zinc-200">
              No chapters in "{currentSubject.name}" yet
            </h4>
            <p className="text-xs text-slate-500 dark:text-zinc-400 max-w-sm mx-auto">
              Add chapters one by one or paste your syllabus chapter list. Every new chapter starts as <span className="font-semibold">● Not Started (Grey)</span>.
            </p>
            <button
              onClick={() => onAddChapter(currentSubject.id)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold"
            >
              <Plus className="w-4 h-4" />
              Add Chapter
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-zinc-800 bg-slate-50/80 dark:bg-zinc-900/80 text-xs font-semibold text-slate-500 dark:text-zinc-400">
                  <th className="py-3 px-3 w-12 text-center">#</th>
                  <th className="py-3 px-4 min-w-[200px]">Chapter name</th>
                  <th className="py-3 px-4 whitespace-nowrap">Started on</th>
                  <th className="py-3 px-4 whitespace-nowrap">Last revised</th>
                  <th className="py-3 px-4 whitespace-nowrap">Status</th>
                  <th className="py-3 px-4 min-w-[180px]">Important notes</th>
                  <th className="py-3 px-4 text-right whitespace-nowrap">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-zinc-800">
                {subjectChapters.map((ch, idx) => {
                  const hasNotes = Object.values(ch.importantNotes || {}).some(v => v && v.trim() !== '');
                  return (
                    <tr key={ch.id} className="hover:bg-slate-50/60 dark:hover:bg-zinc-800/40 transition">
                      {/* Reorder Column */}
                      <td className="py-3 px-3 text-center">
                        <div className="flex flex-col items-center gap-0.5">
                          <button
                            disabled={idx === 0}
                            onClick={() => onReorderChapter(ch.id, 'up')}
                            className="text-slate-400 hover:text-indigo-600 disabled:opacity-20"
                            title="Move Up"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <span className="text-[11px] font-bold text-slate-400">{idx + 1}</span>
                          <button
                            disabled={idx === subjectChapters.length - 1}
                            onClick={() => onReorderChapter(ch.id, 'down')}
                            className="text-slate-400 hover:text-indigo-600 disabled:opacity-20"
                            title="Move Down"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                      {/* Chapter Name */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white">{ch.title}</div>
                        <div className="text-[11px] text-slate-400">
                          {ch.revisionHistory?.length > 0
                            ? `Revised ${ch.revisionHistory.length}x`
                            : 'Never completed'}
                        </div>
                      </td>

                      {/* Started On (Auto-recorded on Start or manually editable) */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        {ch.startedOn ? (
                          <input
                            type="date"
                            value={toInputDateValue(ch.startedOn)}
                            onChange={(e) => onUpdateChapterDates(ch.id, 'startedOn', e.target.value)}
                            className="text-xs bg-transparent border border-slate-200 dark:border-zinc-700 rounded-lg px-2 py-1 text-slate-700 dark:text-zinc-300"
                          />
                        ) : (
                          <button
                            onClick={() => onStartChapter(ch.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-300"
                          >
                            <Play className="w-3 h-3" />
                            Start Chapter
                          </button>
                        )}
                      </td>

                      {/* Last Revised */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex flex-col">
                          <input
                            type="date"
                            value={toInputDateValue(ch.lastRevised)}
                            onChange={(e) => onUpdateChapterDates(ch.id, 'lastRevised', e.target.value)}
                            className="text-xs bg-transparent border border-slate-200 dark:border-zinc-700 rounded-lg px-2 py-1 text-slate-700 dark:text-zinc-300"
                          />
                          {ch.lastRevised && (
                            <span className="text-[10px] text-slate-400 mt-0.5">
                              {ch.daysSinceRev === 0 ? 'Today' : `${ch.daysSinceRev}d ago`}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Status Badge (Grey ● / Green ● / Yellow ● / Orange ● / Red ●) */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <StatusBadge status={ch.status} />
                      </td>

                      {/* Important Notes */}
                      <td className="py-3 px-4">
                        <button
                          onClick={() => onOpenNotes(ch)}
                          className="inline-flex items-center gap-1.5 text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline max-w-[200px] truncate"
                        >
                          <FileText className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">
                            {hasNotes
                              ? ch.importantNotes.struggles ||
                                ch.importantNotes.focus ||
                                ch.importantNotes.formulas ||
                                ch.importantNotes.mistakes ||
                                ch.importantNotes.reminders
                              : 'Add struggles / formulas...'}
                          </span>
                        </button>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => onOpenRevise(ch)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                            title="Mark Completed / Revised"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>{ch.lastRevised ? 'Revise' : 'Complete'}</span>
                          </button>
                          <button
                            onClick={() => onEditChapter(ch)}
                            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-zinc-800"
                            title="Edit Chapter Name"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onDeleteChapter(ch)}
                            className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                            title="Delete Chapter"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// VIEW 3: ALL CHAPTERS (SEARCH & FILTERS)
// ============================================================================
function AllChaptersView({
  subjects,
  enrichedChapters,
  searchQuery,
  setSearchQuery,
  filterSubject,
  setFilterSubject,
  filterStatus,
  setFilterStatus,
  sortField,
  setSortField,
  sortDirection,
  setSortDirection,
  onAddChapter,
  onStartChapter,
  onOpenRevise,
  onOpenNotes,
  onEditChapter,
  onDeleteChapter,
  onUpdateChapterDates
}) {
  const filtered = useMemo(() => {
    return enrichedChapters
      .filter((ch) => {
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = ch.title.toLowerCase().includes(q);
          const matchNotes = Object.values(ch.importantNotes || {}).some(
            v => typeof v === 'string' && v.toLowerCase().includes(q)
          );
          if (!matchTitle && !matchNotes) return false;
        }
        if (filterSubject !== 'all' && ch.subjectId !== filterSubject) return false;
        if (filterStatus === 'due_only') {
          return ['revision_due', 'overdue', 'revise_asap'].includes(ch.status);
        }
        if (filterStatus === 'overdue_only') {
          return ['overdue', 'revise_asap'].includes(ch.status);
        }
        if (filterStatus !== 'all' && ch.status !== filterStatus) return false;
        return true;
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortField === 'urgency') {
          cmp = STATUS_CONFIG[a.status].priority - STATUS_CONFIG[b.status].priority;
        } else if (sortField === 'title') {
          cmp = a.title.localeCompare(b.title);
        } else if (sortField === 'startedOn') {
          cmp = (a.startedOn || '').localeCompare(b.startedOn || '');
        } else if (sortField === 'lastRevised') {
          cmp = (a.lastRevised || '').localeCompare(b.lastRevised || '');
        } else {
          cmp = (a.order || 0) - (b.order || 0);
        }
        return sortDirection === 'asc' ? cmp : -cmp;
      });
  }, [enrichedChapters, searchQuery, filterSubject, filterStatus, sortField, sortDirection]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            All Syllabus Chapters
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
            Search, filter by status or subject, and sort by start or revision date.
          </p>
        </div>
        <button
          onClick={onAddChapter}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Chapter
        </button>
      </div>

      {/* Search & Filter Controls */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search chapter name or notes..."
              className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
            />
          </div>

          <select
            value={filterSubject}
            onChange={(e) => setFilterSubject(e.target.value)}
            className="px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-700 dark:text-zinc-200"
          >
            <option value="all">All Subjects</option>
            {subjects.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-700 dark:text-zinc-200"
          >
            <option value="all">All Statuses</option>
            <option value="not_started">● Not Started (Grey)</option>
            <option value="recently_revised">● Recently Revised (Green)</option>
            <option value="revision_due">● Revision Due (Yellow)</option>
            <option value="overdue">● Overdue (Orange)</option>
            <option value="revise_asap">● Revise ASAP (Red)</option>
            <option value="due_only">Due + Overdue Only</option>
            <option value="overdue_only">Overdue + ASAP Only</option>
          </select>

          <div className="flex gap-2">
            <select
              value={sortField}
              onChange={(e) => setSortField(e.target.value)}
              className="flex-1 px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-700 dark:text-zinc-200"
            >
              <option value="custom">Sort: Custom Order</option>
              <option value="urgency">Sort: Urgency</option>
              <option value="startedOn">Sort: Started Date</option>
              <option value="lastRevised">Sort: Last Revised</option>
              <option value="title">Sort: Alphabetical</option>
            </select>
            <button
              onClick={() => setSortDirection(d => (d === 'asc' ? 'desc' : 'asc'))}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-600 dark:text-zinc-300"
              title="Toggle Sort Direction"
            >
              <ArrowUpDown className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Status Filter Pills */}
        <div className="flex items-center gap-2 flex-wrap pt-1">
          {[
            { id: 'all', label: 'All Chapters' },
            { id: 'not_started', label: '● Not Started (Grey)' },
            { id: 'recently_revised', label: '● Recently Revised (Green)' },
            { id: 'due_only', label: '● Due for Revision' },
            { id: 'overdue_only', label: '● Overdue Only' }
          ].map(pill => (
            <button
              key={pill.id}
              onClick={() => setFilterStatus(pill.id)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                filterStatus === pill.id
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400 hover:bg-slate-200'
              }`}
            >
              {pill.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-slate-200 dark:border-zinc-800 shadow-sm overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-10 text-center text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
            No chapters match the current filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-zinc-800 bg-slate-50/80 dark:bg-zinc-900/80 text-xs font-semibold text-slate-500 dark:text-zinc-400">
                  <th className="py-3 px-4">Subject</th>
                  <th className="py-3 px-4 min-w-[180px]">Chapter name</th>
                  <th className="py-3 px-4 whitespace-nowrap">Started on</th>
                  <th className="py-3 px-4 whitespace-nowrap">Last revised</th>
                  <th className="py-3 px-4 whitespace-nowrap">Status</th>
                  <th className="py-3 px-4 min-w-[160px]">Important notes</th>
                  <th className="py-3 px-4 text-right whitespace-nowrap">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-zinc-800">
                {filtered.map((ch) => {
                  const sub = subjects.find(s => s.id === ch.subjectId);
                  return (
                    <tr key={ch.id} className="hover:bg-slate-50/60 dark:hover:bg-zinc-800/40">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300">
                          {sub?.code || sub?.name || 'Subject'}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">
                        {ch.title}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap text-xs">
                        {ch.startedOn ? (
                          formatDateDisplay(ch.startedOn)
                        ) : (
                          <button
                            onClick={() => onStartChapter(ch.id)}
                            className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
                          >
                            + Start
                          </button>
                        )}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap text-xs text-slate-600 dark:text-zinc-300">
                        {ch.lastRevised ? formatDateDisplay(ch.lastRevised) : 'Never'}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <StatusBadge status={ch.status} />
                      </td>
                      <td className="py-3 px-4">
                        <button
                          onClick={() => onOpenNotes(ch)}
                          className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline truncate max-w-[180px] block"
                        >
                          {ch.importantNotes?.struggles ||
                            ch.importantNotes?.formulas ||
                            ch.importantNotes?.focus ||
                            'Open notes...'}
                        </button>
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => onOpenRevise(ch)}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white"
                          >
                            {ch.lastRevised ? 'Revise' : 'Complete'}
                          </button>
                          <button
                            onClick={() => onEditChapter(ch)}
                            className="p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onDeleteChapter(ch)}
                            className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// VIEW 4: REVISION SCHEDULE
// ============================================================================
function RevisionScheduleView({ subjects, enrichedChapters, onOpenRevise, onSnooze, onOpenNotes }) {
  const redChapters = enrichedChapters.filter(c => c.status === 'revise_asap');
  const orangeChapters = enrichedChapters.filter(c => c.status === 'overdue');
  const yellowChapters = enrichedChapters.filter(c => c.status === 'revision_due');
  const greenChapters = enrichedChapters.filter(c => c.status === 'recently_revised');

  const Section = ({ title, subtitle, list }) => (
    <div className="space-y-3">
      <div>
        <h3 className="font-bold text-base text-slate-900 dark:text-white">
          {title} ({list.length})
        </h3>
        <p className="text-xs text-slate-500 dark:text-zinc-400">{subtitle}</p>
      </div>
      {list.length === 0 ? (
        <div className="p-4 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-xs text-slate-400">
          No chapters in this stage.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {list.map((ch) => {
            const sub = subjects.find(s => s.id === ch.subjectId);
            const cfg = STATUS_CONFIG[ch.status];
            return (
              <div
                key={ch.id}
                className={`p-4 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 border-l-4 ${cfg.borderLeftClass} shadow-sm flex flex-col justify-between gap-3`}
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                      {sub?.name || 'Subject'}
                    </span>
                    <StatusBadge status={ch.status} />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">{ch.title}</h4>
                  <p className="text-xs text-slate-500 dark:text-zinc-400">
                    Last revised: {formatDateDisplay(ch.lastRevised)} ({ch.daysSinceRev}d elapsed)
                  </p>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-zinc-800">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onOpenNotes(ch)}
                      className="px-2.5 py-1 text-xs font-semibold rounded bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300"
                    >
                      Notes
                    </button>
                    {ch.status !== 'recently_revised' && (
                      <>
                        <button
                          onClick={() => onSnooze(ch.id, 1)}
                          className="px-2 py-1 text-xs rounded border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400"
                        >
                          Snooze +1d
                        </button>
                        <button
                          onClick={() => onSnooze(ch.id, 3)}
                          className="px-2 py-1 text-xs rounded border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400"
                        >
                          +3d
                        </button>
                      </>
                    )}
                  </div>
                  <button
                    onClick={() => onOpenRevise(ch)}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white"
                  >
                    Mark Revised
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          Revision Schedule
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
          Automatic progression: Green (0–2d) → Yellow (3–5d) → Orange (6–9d) → Red (10+d).
        </p>
      </div>

      <Section
        title="● Revise ASAP (Red — 10+ Days)"
        subtitle="Highest priority chapters requiring immediate revision."
        list={redChapters}
      />
      <Section
        title="● Overdue (Orange — 6–9 Days)"
        subtitle="Chapters that have slipped past their due window."
        list={orangeChapters}
      />
      <Section
        title="● Revision Due (Yellow — 3–5 Days)"
        subtitle="Ideal spaced repetition window to reinforce memory."
        list={yellowChapters}
      />
      <Section
        title="● Recently Revised (Green — 0–2 Days)"
        subtitle="Recently completed or revised chapters."
        list={greenChapters}
      />
    </div>
  );
}

// ============================================================================
// VIEW 5: REVISION HISTORY
// ============================================================================
function RevisionHistoryView({ subjects, enrichedChapters }) {
  const logs = useMemo(() => {
    const items = [];
    enrichedChapters.forEach((ch) => {
      (ch.revisionHistory || []).forEach((rev) => {
        items.push({
          ...rev,
          chapterTitle: ch.title,
          subjectId: ch.subjectId,
          totalChapterRevisions: ch.revisionHistory.length
        });
      });
    });
    return items.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  }, [enrichedChapters]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          Complete Revision History
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
          Chronological log of revision dates, times, revision counts, and session notes.
        </p>
      </div>

      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-slate-200 dark:border-zinc-800 shadow-sm p-5">
        {logs.length === 0 ? (
          <div className="p-8 text-center text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
            No revisions recorded yet. Mark any chapter as completed or revised to begin logging history.
          </div>
        ) : (
          <div className="space-y-3">
            {logs.map((log) => {
              const sub = subjects.find(s => s.id === log.subjectId);
              return (
                <div
                  key={log.id}
                  className="p-4 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200 dark:border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300">
                        {sub?.name || 'Subject'}
                      </span>
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {log.chapterTitle}
                      </span>
                      <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                        Revision #{log.count}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-zinc-300">{log.note}</p>
                  </div>
                  <div className="text-xs text-slate-500 dark:text-zinc-400 font-medium shrink-0">
                    {formatDateDisplay(log.timestamp, true)}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// VIEW 6: NOTIFICATIONS & SMART ALARM CENTRE
// ============================================================================
function NotificationsView({
  subjects,
  attentionChapters,
  browserNotifPermission,
  onRequestPermission,
  onSendTestNotification,
  notificationSettings,
  setNotificationSettings,
  onOpenRevise,
  onSnooze
}) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          Smart Alarm & Reminder Centre
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
          Automatic revision reminders prioritized by Red (Revise ASAP), Orange (Overdue), and Yellow (Due).
        </p>
      </div>

      {/* Browser Permission & Preferred Time Card */}
      <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <BellRing className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                Browser Notification Status: <span className="capitalize text-indigo-600 dark:text-indigo-400">{browserNotifPermission}</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                {browserNotifPermission === 'granted'
                  ? 'System notifications are active for due and overdue chapters.'
                  : browserNotifPermission === 'denied'
                  ? 'Browser notifications are blocked in your browser settings. Using the In-App Reminder Centre below as fallback.'
                  : 'Enable browser permissions to receive desktop/mobile alerts.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {browserNotifPermission !== 'granted' && browserNotifPermission !== 'unsupported' && (
              <button
                onClick={onRequestPermission}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold"
              >
                Enable Permission
              </button>
            )}
            <button
              onClick={onSendTestNotification}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 text-xs font-semibold text-slate-700 dark:text-zinc-300 hover:bg-slate-100"
            >
              Test Alert
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-100 dark:border-zinc-800 text-xs">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50">
            <span className="font-semibold text-slate-700 dark:text-zinc-300">
              Preferred Daily Reminder Time
            </span>
            <input
              type="time"
              value={notificationSettings.preferredTime}
              onChange={(e) =>
                setNotificationSettings(prev => ({ ...prev, preferredTime: e.target.value }))
              }
              className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-900"
            />
          </div>

          <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 cursor-pointer">
            <span className="font-semibold text-slate-700 dark:text-zinc-300">
              Play Audio Chime on Revision Complete
            </span>
            <input
              type="checkbox"
              checked={notificationSettings.soundEnabled}
              onChange={(e) =>
                setNotificationSettings(prev => ({ ...prev, soundEnabled: e.target.checked }))
              }
              className="w-4 h-4 rounded text-indigo-600"
            />
          </label>
        </div>
      </div>

      {/* In-App Fallback Reminder Cards */}
      <div className="space-y-3">
        <h3 className="font-bold text-base text-slate-900 dark:text-white">
          Active Chapter Reminders ({attentionChapters.length})
        </h3>
        {attentionChapters.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-xs text-slate-500">
            No chapters currently require a revision reminder.
          </div>
        ) : (
          <div className="space-y-3">
            {attentionChapters.map((ch) => {
              const sub = subjects.find(s => s.id === ch.subjectId);
              return (
                <div
                  key={ch.id}
                  className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                        StudyTrack — Revision Reminder
                      </span>
                      <StatusBadge status={ch.status} />
                    </div>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">
                      Your chapter "{ch.title}" ({sub?.name}) is {ch.status === 'revision_due' ? 'due for revision today' : 'overdue for revision'}. Time to revise!
                    </p>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <button
                      onClick={() => onSnooze(ch.id, 1)}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300"
                    >
                      Snooze 1d
                    </button>
                    <button
                      onClick={() => onOpenRevise(ch)}
                      className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white"
                    >
                      Mark Revised
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// VIEW 7: SETTINGS & DATA RELIABILITY
// ============================================================================
function SettingsView({
  subjects,
  chapters,
  isDarkMode,
  setIsDarkMode,
  onExport,
  onImport,
  onClearAll
}) {
  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          Settings & Data Backup
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
          Export or import your syllabus data and customize appearance.
        </p>
      </div>

      <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-4">
        <h3 className="font-bold text-base text-slate-900 dark:text-white">Appearance</h3>
        <div className="flex items-center justify-between text-xs sm:text-sm">
          <span>Theme Mode</span>
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 dark:bg-zinc-800 font-semibold"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            <span>{isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}</span>
          </button>
        </div>
      </div>

      <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm space-y-4">
        <h3 className="font-bold text-base text-slate-900 dark:text-white">
          Persistent Data Export & Import
        </h3>
        <p className="text-xs text-slate-500 dark:text-zinc-400">
          Currently storing {subjects.length} subject(s) and {chapters.length} chapter(s) in persistent browser storage.
        </p>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={onExport}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold"
          >
            <Download className="w-4 h-4" />
            Export Backup (.json)
          </button>
          <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 text-slate-800 dark:text-zinc-200 text-xs font-bold cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>Import Backup (.json)</span>
            <input type="file" accept=".json" onChange={onImport} className="hidden" />
          </label>
        </div>
      </div>

      <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-rose-200 dark:border-rose-900/50 shadow-sm space-y-3">
        <h3 className="font-bold text-base text-rose-600">Reset Workspace</h3>
        <p className="text-xs text-slate-500 dark:text-zinc-400">
          Clear all subjects and chapters to return to a fresh empty state.
        </p>
        <button
          onClick={onClearAll}
          className="px-4 py-2 rounded-xl border border-rose-300 dark:border-rose-800 text-rose-600 text-xs font-bold hover:bg-rose-50 dark:hover:bg-rose-950/40"
        >
          Clear All Data
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// MODALS (Subject, Chapter + Bulk Add, Revise, Important Notes, Confirm)
// ============================================================================
function SubjectModal({ mode, initialData, onClose, onSave }) {
  const [name, setName] = useState(initialData?.name || '');
  const [code, setCode] = useState(initialData?.code || '');
  const [color, setColor] = useState(initialData?.color || 'indigo');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave({
      name: name.trim(),
      code: (code.trim() || name.trim().slice(0, 4)).toUpperCase(),
      color
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-base text-slate-900 dark:text-white">
            {mode === 'add_subject' ? 'Create New Subject' : 'Rename / Edit Subject'}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="font-semibold text-slate-700 dark:text-zinc-300">Subject Name *</label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Mathematics, Organic Chemistry, Economics..."
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
            />
          </div>
          <div className="space-y-1">
            <label className="font-semibold text-slate-700 dark:text-zinc-300">
              Course / Board Tag (Optional)
            </label>
            <input
              type="text"
              maxLength={10}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="e.g. MATH-101, CBSE, AP, NEET"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white uppercase"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
            >
              Save Subject
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ChapterModal({ mode, subjects, initialData, onClose, onSave }) {
  const [isBulk, setIsBulk] = useState(false);
  const [title, setTitle] = useState(initialData?.title || '');
  const [bulkText, setBulkText] = useState('');
  const [subjectId, setSubjectId] = useState(initialData?.subjectId || subjects[0]?.id || '');
  const [startedOn, setStartedOn] = useState(
    initialData?.startedOn ? toInputDateValue(initialData.startedOn) : ''
  );
  const [markCompletedNow, setMarkCompletedNow] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (mode === 'add_chapter' && isBulk) {
      const lines = bulkText
        .split('\n')
        .map(l => l.trim())
        .filter(Boolean);
      if (lines.length === 0) return;
      onSave({
        subjectId,
        titles: lines,
        startedOn: startedOn || null,
        markCompletedNow
      });
      return;
    }
    if (!title.trim()) return;
    onSave({
      subjectId,
      title: title.trim(),
      startedOn: startedOn || null,
      markCompletedNow
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-base text-slate-900 dark:text-white">
            {mode === 'add_chapter' ? 'Add Chapter to Syllabus' : 'Edit Chapter'}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {mode === 'add_chapter' && (
          <div className="flex gap-2 p-1 rounded-xl bg-slate-100 dark:bg-zinc-800 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsBulk(false)}
              className={`flex-1 py-1.5 rounded-lg ${
                !isBulk ? 'bg-white dark:bg-zinc-900 shadow-sm text-indigo-600' : 'text-slate-500'
              }`}
            >
              Single Chapter
            </button>
            <button
              type="button"
              onClick={() => setIsBulk(true)}
              className={`flex-1 py-1.5 rounded-lg ${
                isBulk ? 'bg-white dark:bg-zinc-900 shadow-sm text-indigo-600' : 'text-slate-500'
              }`}
            >
              Bulk Add List
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="font-semibold text-slate-700 dark:text-zinc-300">Subject</label>
            <select
              value={subjectId}
              onChange={(e) => setSubjectId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>

          {mode === 'add_chapter' && isBulk ? (
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-zinc-300">
                Paste Chapter Names (One per line) *
              </label>
              <textarea
                rows={5}
                required
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                placeholder={'Chapter 1: Real Numbers\nChapter 2: Polynomials\nChapter 3: Linear Equations'}
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
              />
            </div>
          ) : (
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-zinc-300">Chapter Name *</label>
              <input
                type="text"
                required
                autoFocus
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Real Numbers / Rotational Motion"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="font-semibold text-slate-700 dark:text-zinc-300">
              Started Studying On (Leave blank if ● Not Started yet)
            </label>
            <input
              type="date"
              value={startedOn}
              onChange={(e) => setStartedOn(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
            />
          </div>

          {mode === 'add_chapter' && (
            <label className="flex items-center gap-2 p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/60 cursor-pointer">
              <input
                type="checkbox"
                checked={markCompletedNow}
                onChange={(e) => setMarkCompletedNow(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600"
              />
              <span className="text-slate-700 dark:text-zinc-300 font-medium">
                Already completed? Start in Green ● Recently Revised status
              </span>
            </label>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-zinc-400 hover:bg-slate-100 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ReviseModal({ chapter, onClose, onConfirm }) {
  const [note, setNote] = useState('');
  const [dateVal, setDateVal] = useState(getTodayDateString());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-base text-slate-900 dark:text-white">
            {chapter.lastRevised ? 'Mark Chapter as Revised' : 'Complete Chapter & Start Revision Timer'}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/60 flex items-center justify-between text-xs">
          <span className="font-bold text-slate-900 dark:text-white">{chapter.title}</span>
          <StatusBadge status={chapter.status} />
        </div>

        <div className="space-y-3 text-xs">
          <div className="space-y-1">
            <label className="font-semibold text-slate-700 dark:text-zinc-300">
              Completion / Revision Date
            </label>
            <input
              type="date"
              value={dateVal}
              max={getTodayDateString()}
              onChange={(e) => setDateVal(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
            />
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-slate-700 dark:text-zinc-300">
              Session Note (Optional)
            </label>
            <textarea
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. Solved past paper questions, reviewed key theorems..."
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
            />
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2 text-xs">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-600 dark:text-zinc-400 hover:bg-slate-100 font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              const parts = dateVal.split('-');
              const customISO =
                dateVal === getTodayDateString()
                  ? null
                  : new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]), 12, 0, 0).toISOString();
              onConfirm(chapter.id, note, customISO);
            }}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
          >
            Confirm & Set to Green ●
          </button>
        </div>
      </div>
    </div>
  );
}

function NotesModal({ chapter, subject, onClose, onSaveNotes, onQuickRevise }) {
  const [tab, setTab] = useState('struggles');
  const [notes, setNotes] = useState({
    struggles: chapter.importantNotes?.struggles || '',
    focus: chapter.importantNotes?.focus || '',
    mistakes: chapter.importantNotes?.mistakes || '',
    formulas: chapter.importantNotes?.formulas || '',
    reminders: chapter.importantNotes?.reminders || ''
  });

  const sections = [
    { id: 'struggles', label: 'Struggles', prompt: 'Topics I struggle with in this chapter:' },
    { id: 'focus', label: 'Extra Focus', prompt: 'Topics requiring additional focus:' },
    { id: 'mistakes', label: 'Common Mistakes', prompt: 'Common mistakes & traps to avoid:' },
    { id: 'formulas', label: 'Formulas & Concepts', prompt: 'Important formulas, definitions & concepts:' },
    { id: 'reminders', label: 'Reminders', prompt: 'Personal study reminders:' },
    { id: 'history', label: `History (${chapter.revisionHistory?.length || 0})` }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-2xl rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-2xl flex flex-col max-h-[90vh]">
        <div className="p-5 border-b border-slate-200 dark:border-zinc-800 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                {subject?.name || 'Subject'}
              </span>
              <StatusBadge status={chapter.status} />
            </div>
            <h3 className="font-bold text-lg text-slate-900 dark:text-white mt-1">
              {chapter.title}
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center gap-1 px-5 pt-2 border-b border-slate-200 dark:border-zinc-800 overflow-x-auto">
          {sections.map(s => (
            <button
              key={s.id}
              onClick={() => setTab(s.id)}
              className={`px-3 py-2 text-xs font-bold border-b-2 whitespace-nowrap ${
                tab === s.id
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="p-5 flex-1 overflow-y-auto text-xs space-y-2">
          {tab === 'history' ? (
            (chapter.revisionHistory || []).length === 0 ? (
              <p className="text-slate-400 py-4">No revisions logged for this chapter yet.</p>
            ) : (
              <div className="space-y-2">
                {chapter.revisionHistory.map((h) => (
                  <div
                    key={h.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700"
                  >
                    <div className="flex justify-between font-bold text-slate-800 dark:text-zinc-200">
                      <span>Revision #{h.count}</span>
                      <span>{formatDateDisplay(h.timestamp, true)}</span>
                    </div>
                    <p className="text-slate-600 dark:text-zinc-400 mt-1">{h.note}</p>
                  </div>
                ))}
              </div>
            )
          ) : (
            <>
              <label className="font-semibold text-slate-700 dark:text-zinc-300 block">
                {sections.find(s => s.id === tab)?.prompt}
              </label>
              <textarea
                rows={8}
                value={notes[tab]}
                onChange={(e) => setNotes(prev => ({ ...prev, [tab]: e.target.value }))}
                placeholder="Write your chapter notes here..."
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-white"
              />
            </>
          )}
        </div>

        <div className="p-4 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between text-xs">
          <button
            onClick={() => onQuickRevise(chapter)}
            className="px-3.5 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold"
          >
            Mark Chapter Revised
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-zinc-400 font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={() => onSaveNotes(chapter.id, notes)}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
            >
              Save Notes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ConfirmModal({ title, message, confirmLabel, onClose, onConfirm }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 p-6 shadow-2xl space-y-4">
        <h3 className="font-bold text-base text-slate-900 dark:text-white">{title}</h3>
        <p className="text-xs text-slate-500 dark:text-zinc-400">{message}</p>
        <div className="flex justify-end gap-2 pt-2 text-xs">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-600 dark:text-zinc-400 hover:bg-slate-100 font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold"
          >
            {confirmLabel || 'Confirm'}
          </button>
        </div>
      </div>
    </div>
  );
}
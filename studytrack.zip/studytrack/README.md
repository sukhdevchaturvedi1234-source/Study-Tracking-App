# StudyTrack

A React + Vite + Tailwind CSS app created from the supplied StudyTrack source.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. To create a production build:

```bash
npm run build
```

## Run on an Android phone (no laptop)

1. Upload this ZIP to a new Replit project, or create a React/Vite repl and upload the project files.
2. In the Replit Shell, run `npm install`.
3. Run `npm run dev -- --host 0.0.0.0` (or use Replit's Run command).
4. Open the web preview.

The app stores subjects, chapters, theme and notification preferences in the browser's localStorage. Use Settings → Export Backup regularly. Browser notifications require permission and may be restricted by the browser or hosting environment.
